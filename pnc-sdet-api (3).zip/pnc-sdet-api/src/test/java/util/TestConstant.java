package util;

public class TestConstant {
    public static final int SUCCESS_CODE =200 ;
    public static final int ERROR_CODE =404 ;
    public static final int ERROR_BAD_REQUEST_CODE =400 ;
    public  static  String BASE_URL= "https://restcountries.com/v3.1";
    public  static  String END_URL = "/all";
    public  static  String NAME_END_URL = "/name";

    public  static  String CODE_END_URL = "/alpha";
}