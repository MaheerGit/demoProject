package util;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Map;

public class Convertor {

    public static Object fromJson(String jsonString, Type type) {
        return new Gson().fromJson(jsonString, type);
    }
    public static ArrayList<Object> getArrayFromJson(String jsonString) {
         ArrayList<Object> arrayList= (ArrayList<Object>) fromJson(jsonString,
                new TypeToken<ArrayList<Object>>() {
                }.getType());

         return  arrayList;
    }


    public static ArrayList<Map<String, Object>> getCountriesFromJson(String jsonString) {
        ArrayList<Map<String, Object>> arrayList= (ArrayList<Map<String, Object>>) fromJson(jsonString,
                new TypeToken<ArrayList<Object>>() {
                }.getType());

        return  arrayList;
    }
}