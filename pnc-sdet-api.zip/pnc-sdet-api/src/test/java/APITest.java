import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.Test;
import util.Convertor;
import util.TestConstant;

import java.util.ArrayList;
import java.util.Map;

public class APITest {

@Test
public void verifyAllCountriesAPI_responseBody(){
    RestAssured.baseURI= TestConstant.BASE_URL;
    RequestSpecification request = RestAssured.given();
    Response response = request.get(TestConstant.END_URL);
    Assert.assertNotNull(response.getBody());
    Assert.assertEquals(response.getStatusCode(),TestConstant.SUCCESS_CODE);

   }

    @Test
    public void verifyAllCountriesAPI_statusCode(){
        RestAssured.baseURI= TestConstant.BASE_URL;
        RequestSpecification request = RestAssured.given();
        Response response = request.get(TestConstant.END_URL);
        Assert.assertNotNull(response);
        Assert.assertEquals(response.getStatusCode(),TestConstant.SUCCESS_CODE);

    }

    @Test
    public void verifyAllCountries_sizeShouldNotEmpty(){
        RestAssured.baseURI= TestConstant.BASE_URL;
        RequestSpecification request = RestAssured.given();
        Response response = request.get(TestConstant.END_URL);
        Assert.assertEquals(response.getStatusCode(),TestConstant.SUCCESS_CODE);
        ArrayList<Object> arrayOfCountries = Convertor.getArrayFromJson(response.getBody().asString());
        Assert.assertNotEquals(0, arrayOfCountries.size());

    }

    @Test
    public void verifyAllCountries_nameShouldNotEmptyOrNull(){
        RestAssured.baseURI= TestConstant.BASE_URL;
        RequestSpecification request = RestAssured.given();
        Response response = request.get(TestConstant.END_URL);
        Assert.assertEquals(response.getStatusCode(),TestConstant.SUCCESS_CODE );
        ArrayList<Map<String, Object>> arrayOfCountries = Convertor.getCountriesFromJson(response.getBody().asString());
        boolean isCountryNameEmptyOrNull= false;
        for(Map<String, Object> countryData : arrayOfCountries){
           String name =  countryData.get("name").toString() ;
           if((name.isEmpty())|| name ==null ){
                isCountryNameEmptyOrNull=true;
            }
            Assert.assertFalse(isCountryNameEmptyOrNull);
        }
     }


    @Test
    public void verifyNameAPI_responseCode_when_name_exist(){
        RestAssured.baseURI= TestConstant.BASE_URL;
        RequestSpecification request = RestAssured.given();
        Response response = request.get(TestConstant.NAME_END_URL + "/united");
        Assert.assertEquals(response.getStatusCode(),TestConstant.SUCCESS_CODE);

    }


    @Test
    public void verifyNameAPI_when_name_blank(){
        RestAssured.baseURI= TestConstant.BASE_URL;
        RequestSpecification request = RestAssured.given();
        Response response = request.get(TestConstant.NAME_END_URL + "/");
        Assert.assertEquals( response.getStatusCode(),TestConstant.ERROR_CODE);
    }

    @Test
    public void verifyNameAPI_when_name_not_exist(){
        RestAssured.baseURI= TestConstant.BASE_URL;
        RequestSpecification request = RestAssured.given();
        Response response = request.get(TestConstant.NAME_END_URL + "/ABCS");

        Assert.assertEquals(response.getStatusCode(),TestConstant.ERROR_CODE);
    }

    @Test
    public void verifyNameAPI_responseBody_when_name_exist(){
        String givenName = "united";
        RestAssured.baseURI= TestConstant.BASE_URL;
        RequestSpecification request = RestAssured.given();
        Response response = request.get(TestConstant.NAME_END_URL + "/"+givenName);
        Assert.assertEquals(response.getStatusCode(),TestConstant.SUCCESS_CODE);
        ArrayList<Map<String, Object>> arrayOfCountries = Convertor.getCountriesFromJson(response.getBody().asString());
        boolean isCapitalNameContainsGivenName= true;
        for(Map<String, Object> countryData : arrayOfCountries){

          Map<String, Object>  object = (Map<String, Object>) countryData.get("name");
          String commonName = object.get("common").toString();

            if( commonName!=null && commonName.contains(givenName)){
                isCapitalNameContainsGivenName=false;
            }
        }
        Assert.assertTrue(isCapitalNameContainsGivenName);
    }

    @Test
    public void verifyCodeAPI_responseCode_when_code_exist(){
        RestAssured.baseURI= TestConstant.BASE_URL;
        RequestSpecification request = RestAssured.given();
        Response response = request.get(TestConstant.CODE_END_URL + "/in");
        Assert.assertEquals(response.getStatusCode(),TestConstant.SUCCESS_CODE);

    }


    @Test
    public void verifyCodeAPI_when_code_blank(){
        RestAssured.baseURI= TestConstant.BASE_URL;
        RequestSpecification request = RestAssured.given();
        Response response = request.get(TestConstant.CODE_END_URL + "/");
        Assert.assertEquals( response.getStatusCode(), TestConstant.ERROR_BAD_REQUEST_CODE);
    }

    @Test
    public void verifyCodeAPI_when_code_not_exist(){
        RestAssured.baseURI= TestConstant.BASE_URL;
        RequestSpecification request = RestAssured.given();
        Response response = request.get(TestConstant.CODE_END_URL + "/ABCS");

        Assert.assertEquals(response.getStatusCode(),TestConstant.ERROR_BAD_REQUEST_CODE);
    }

    @Test
    public void verifyCodeAPI_responseBody_when_code_exist(){
        String givenCODE = "PE";
        RestAssured.baseURI= TestConstant.BASE_URL;
        RequestSpecification request = RestAssured.given();
        Response response = request.get(TestConstant.CODE_END_URL + "/"+givenCODE);
        Assert.assertEquals(response.getStatusCode(),TestConstant.SUCCESS_CODE);
        ArrayList<Map<String, Object>> arrayOfCountries = Convertor.getCountriesFromJson(response.getBody().asString());
        boolean isCapitalNameContainsGivenName= true;
        for(Map<String, Object> countryData : arrayOfCountries){

            Map<String, Object>  object = (Map<String, Object>) countryData.get("name");
            String commonName = object.get("common").toString();

            if( commonName!=null && commonName.contains(givenCODE)){
                isCapitalNameContainsGivenName=false;
            }
        }
        Assert.assertTrue(isCapitalNameContainsGivenName);
    }

}